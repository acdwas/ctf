#!/bin/bash

`pwd`/PoW
if [ $? == 0 ]; then
	echo "\n"
	`pwd`/ret-of-the-rops
fi
